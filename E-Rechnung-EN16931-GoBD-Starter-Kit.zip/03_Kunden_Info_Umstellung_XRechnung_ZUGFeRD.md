# Muster-Information an B2B-Kunden: Versand unserer Ausgangsrechnungen als E-Rechnung (ZUGFeRD 2.3 / XRechnung 3.0)

**Betreff:** Wichtige Information für Ihre Buchhaltung: Umstellung unseres Rechnungsversands auf E-Rechnungen (EN 16931)

Sehr geehrte Damen und Herren,

zur Erfüllung der gesetzlichen Vorgaben nach § 14 UStG stellen wir unseren B2B-Rechnungsversand planmäßig auf strukturierte elektronische Rechnungen nach der Norm **EN 16931** um.

Sie erhalten unsere Ausgangsrechnungen künftig im hybriden Format **ZUGFeRD 2.3 (Profil EN 16931)** — dieses verbindet ein gewohnt lesbares PDF-Dokument mit dem maschinenlesbaren XML-Originaldatensatz für Ihre Buchhaltungssoftware — oder auf Wunsch als reine **XRechnung 3.0 (XML)**.

**Bitte teilen Sie uns kurz mit, falls sich Ihre Empfangsdaten geändert haben:**
1. Gewünschte zentrale E-Mail-Empfangsadresse für E-Rechnungen: `___________________________`
2. Bevorzugtes Format: `[ ] ZUGFeRD 2.3 (PDF + XML)` oder `[ ] XRechnung 3.0 (XML)`
3. Optional: Ihre Leitweg-ID / Käuferreferenz (`BT-10`) oder feste Bestellreferenz (`BT-13`): `___________________________`

Sollten wir bis zum `[Datum]` keine abweichende Mitteilung erhalten, senden wir Ihre E-Rechnungen im ZUGFeRD-2.3-Format an die bei uns hinterlegte Rechnungs-E-Mail-Adresse.

Mit freundlichen Grüßen  
**[Firmenname GmbH]**
