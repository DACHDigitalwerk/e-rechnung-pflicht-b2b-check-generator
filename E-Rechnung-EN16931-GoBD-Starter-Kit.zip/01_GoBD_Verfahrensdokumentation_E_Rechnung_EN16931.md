# Ergänzungsbaustein zur GoBD-Verfahrensdokumentation: Elektronischer Rechnungseingang & Rechnungsausgang (§ 14 UStG n.F. / EN 16931)

**Unternehmen:** [Firmenname GmbH]  
**USt-IdNr.:** [DE123456789]  
**Verantwortlich (Kaufmännische Leitung / Buchhaltung):** [Name, Funktion]  
**Zentrales E-Rechnungs-Postfach:** [rechnung@ihre-domain.de]  
**Gültig ab:** 01.01.2025 (aktualisiert 2026)

## 1. Rechtsgrundlage & Anwendungsbereich
Gemäß § 14 Abs. 1 und Abs. 2 UStG i. d. F. des Wachstumschancengesetzes sowie dem BMF-Schreiben vom 15.10.2024 sind im inländischen B2B-Umsatz elektronische Rechnungen in einem strukturierten elektronischen Format auszustellen, zu übermitteln und zu empfangen, das der europäischen Norm **EN 16931** entspricht (insbesondere **XRechnung 3.0** im UBL-2.1-/CII-XML-Format sowie hybride Formate ab **ZUGFeRD 2.0.1 / 2.3** ohne Profil MINIMUM/BASIC-WL).

## 2. Technischer Empfangsweg & Unveränderbarkeit (GoBD Rz. 119–135)
1. **Zentraler Empfangskanal:** Eingehende strukturierte Rechnungen (`.xml` sowie hybride `.pdf` mit eingebettetem XML) werden über das dedizierte Postfach `[rechnung@ihre-domain.de]` entgegengenommen.
2. **Format- & Schemaprüfung:** Jede eingehende E-Rechnung wird vor der Verbuchung automatisiert auf Wohlgeformtheit, EN-16931-Pflichtangaben (`BT-1` bis `BT-115`, § 14 Abs. 4 UStG) und rechnerische Summenkonsistenz geprüft. Bei hybriden Rechnungen (ZUGFeRD) ist gemäß BMF-Schreiben vorrangig der strukturierte XML-Datensatz maßgeblich.
3. **Revisionssichere Aufbewahrung (§ 14b UStG / § 147 AO):** Das strukturierte Original-XML wird unverändert, maschinell auswertbar und indexiert für die gesetzliche Aufbewahrungsfrist von **8 Jahren** (Buchungsbelege gem. BEG IV) archiviert. Eine ausschließliche Ablage als PDF-Ausdruck oder Papierbeleg ist untersagt.

## 3. Sachliche Rechnungsprüfung & Freigabeworkflow
- Abgleich mit Bestellung / Leistungsnachweis (3-Way-Match), Prüfung der Bankverbindung (IBAN) auf Stammdaten-Übereinstimmung zum Schutz vor CEO-/Invoice-Fraud sowie Dokumentation der Freigabe mit Zeitstempel und Prüferkürzel.
