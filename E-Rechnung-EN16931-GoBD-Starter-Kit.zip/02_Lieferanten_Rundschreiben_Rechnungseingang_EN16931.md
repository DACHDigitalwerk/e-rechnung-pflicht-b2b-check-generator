# Muster-Anschreiben an Lieferanten & Dienstleister: Elektronische Rechnungszustellung nach § 14 UStG (EN 16931)

**Betreff:** Umstellung unseres Rechnungseingangs auf strukturierte E-Rechnungen (EN 16931 / ZUGFeRD 2.3 / XRechnung 3.0)

Sehr geehrte Damen und Herren,  
sehr geehrte Geschäftspartnerinnen und Geschäftspartner,

im Zuge der gesetzlichen E-Rechnungspflicht im B2B-Bereich (§ 14 UStG n.F.) haben wir unseren Rechnungseingang vollständig auf strukturierte elektronische Rechnungen gemäß der europäischen Norm **EN 16931** umgestellt.

Bitte übermitteln Sie Ihre Rechnungen an unser Unternehmen ab sofort bevorzugt in einem der folgenden Formate:
- **ZUGFeRD ab Version 2.0.1 / 2.3** (Profil *EN 16931 / COMFORT* oder *EXTENDED*, hybrides PDF/A-3 mit eingebetteter `factur-x.xml`)
- **XRechnung 3.0** (strukturierte XML-Datei nach UBL 2.1 oder UN/CEFACT CII)

**Unsere zentrale E-Rechnungs-Empfangsadresse lautet:**  
`[rechnung@ihre-domain.de]`

Bitte beachten Sie für eine verzögerungsfreie automatisierte Verarbeitung und pünktliche Zahlung folgende Angaben im XML-Datensatz:
- Vollständige Rechnungsnummer (`BT-1`) und Rechnungsdatum (`BT-2`)
- Unsere Bestellnummer / Auftragsreferenz im Feld `BT-13` (*BuyerOrderReferencedDocument*), sofern vorhanden
- Ihre vollständige USt-IdNr. (`BT-31`) oder Steuernummer (`BT-32`) sowie IBAN (`BT-84`)
- Pro E-Mail bitte genau **eine** Rechnung (inkl. etwaiger leistungsbegründender Anlagen als eingebettetes Objekt oder separates PDF) senden.

Für Rückfragen steht Ihnen unsere Buchhaltung unter `[buchhaltung@ihre-domain.de]` gerne zur Verfügung. Vielen Dank für Ihre Unterstützung!

Mit freundlichen Grüßen  
**[Firmenname GmbH]**  
Kaufmännische Leitung / Kreditorenbuchhaltung
